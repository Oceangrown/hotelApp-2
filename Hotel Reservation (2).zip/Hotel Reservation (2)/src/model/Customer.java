package model;

import java.util.regex.Pattern;

public class Customer {
    private final String firstName;
    private final String lastName;
    private final String email;
    private static final String EMAIL_REGEX_PATTERN = "^(.+)@(.+).(.+)$";

    public Customer(String firstName, String lastName, String email){
        this.validateEmail(email);
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public String getEmail(){
        return email;
    }
    private void validateEmail(final String email){
        Pattern pattern = Pattern.compile(EMAIL_REGEX_PATTERN);

        if(!pattern.matcher(email).matches()){
            throw new IllegalArgumentException("Invalid Email");
        }
    }
    public String toString(){
        return "First Name: " + firstName + "Last Name: " + lastName + "Email: " + email;
    }

}
