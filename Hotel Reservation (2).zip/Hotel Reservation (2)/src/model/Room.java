package model;

public class Room implements IRoom{
    protected final String roomNumber;
    protected final Double price;
    protected final RoomType enumeration;
    protected final boolean isFree = false;

    public Room(final String roomNumber, final Double price, final RoomType enumeration){
        this.roomNumber = roomNumber;
        this.price = price;
        this.enumeration = enumeration;
    }

    @Override
    public String getRoomNumber() {
        return null;
    }

    @Override
    public Double getRoomPrice() {
        return null;
    }

    @Override
    public RoomType getRoomType() {
        return null;
    }

    @Override
    public boolean isFree() {
        return false;

    }
    public String toString(){
        return "Room Number:" + roomNumber + "Price:" + price + "Enumeration:" + enumeration;
    }
}
