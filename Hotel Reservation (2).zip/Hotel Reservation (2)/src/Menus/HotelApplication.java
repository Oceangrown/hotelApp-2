package Menus;

import static Menus.MainMenu.launchMainMenu;

public class HotelApplication {
    public static void main(String[] args){
        launchMainMenu();
    }
}
