package Menus;

import Resource.AdminResource;
import Resource.HotelResource;
import model.Customer;
import model.IRoom;
import model.Room;

import java.sql.Array;
import java.util.*;




public class AdminMenu {
    public AdminMenu adminMenu = null;
    private static final List<IRoom> roomList = new ArrayList<>();
    private static AdminResource adminResource = AdminResource.getInstance();
    private static HotelResource hotelResource = HotelResource.getInstance();

    private AdminMenu(){};

    static void launchAdminMenu(){
        boolean keepRunning = true;
        String optionAdminMenu = null;

        while(keepRunning){
            try{
                Scanner adminMenuScan = new Scanner(System.in);
                System.out.println("--------------------------");
                System.out.println("1. See all Customers");
                System.out.println("2. See all Rooms");
                System.out.println("3. See all Reservations");
                System.out.println("4. Add a Room");
                System.out.println("5. Back to Main Menu");
                System.out.println("Select a Menu option");
                System.out.println("---------------------------");
                switch(optionAdminMenu){
                    case "1" ->{
                        Collection<Customer> allCustomers = adminResource.getAllCustomers();
                        if(allCustomers.isEmpty()){
                            System.out.println("No customer found");
                        } else{
                            for (Customer customer : allCustomers){
                                System.out.println(customer.toString());
                            }
                        }
                    }
                    case "2" -> {
                        Collection<IRoom> roomCollection = adminResource.getAllRooms();
                        if (roomCollection.isEmpty()) {
                            System.out.println("No room found");
                        } else{
                            for (IRoom room : roomCollection){
                                System.out.println(room.toString());
                            }
                        }
                    }
                    case "3" -> adminResource.displayAllReservations();
                    case "4" -> adminResource.addRoom(addRoom());
                    case "5" -> keepRunning = false;
                    default -> System.out.println("Select an option 1-5");

                }

            } catch (Exception ex){
                System.out.println("Error, invalid format");
            }
        }
    }

    private static List<IRoom> addRoom(){
        roomList.clear();
        IRoom room = null;
        roomList.add(room);
        return roomList;
    }
}
