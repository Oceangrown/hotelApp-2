package Menus;

import Resource.AdminResource;
import Resource.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Pattern;



public class MainMenu {
    public static AdminResource adminResource = AdminResource.getInstance();
    public static HotelResource hotelResource = HotelResource.getInstance();
    private static Collection<Reservation> reservationCollection = new HashSet<>();
    private static Collection<IRoom> availableRooms = new HashSet<>();

    private MainMenu(){

    }
    public static void launchMainMenu(){
        boolean keepRunning = true;
        String option = null;
        try (Scanner scanner = new Scanner(System.in)){
            while(keepRunning){
                try{
                    System.out.println("Welcome to the main menu");
                    System.out.println("1. Find and reserve a room");
                    System.out.println("2. See my reservations");
                    System.out.println("3. Create an account");
                    System.out.println("4. Admin");
                    System.out.println("5. Exit");
                    System.out.println("Please select an option 1-5");
                    Integer.parseInt(scanner.nextLine());

                    switch(option){
                        case "1" -> {
                            availableRooms = ReservationService.findRooms();
                            if (availableRooms.isEmpty()){
                                System.out.println("There are no rooms within those dates");
                            }
                            for(IRoom room : availableRooms){
                                System.out.println(room.toString());
                            }
                        }
                        case "2" -> {
                            reservationCollection.clear();
                            String customersEmail = getEmail();
                            reservationCollection = hotelResource.getCustomerReservations(customersEmail);
                            if(reservationCollection.isEmpty()){
                                System.out.println("No reservations under this email");
                            }
                            else
                            {
                                for(Reservation currentReservation : reservationCollection){
                                    currentReservation.toString();
                                }
                            }
                        }
                        case "3" -> {
                            String email = getEmail();
                            String firstName = getFirstName();
                            String lastName = getLastName();
                            hotelResource.createACustomer(email, firstName, lastName);
                        }
                        case "4" -> AdminMenu.launchAdminMenu();
                        case "5" -> keepRunning = false;
                        default -> System.out.println("Select option 1-5");


                    }
                }catch (Exception ex){
                    System.out.println(ex.toString());
                }
            }
        }
    }
    public static String getSwitchOption(){
        String switchOption;
        Scanner mainMenuScanner = new Scanner(System.in);
        switchOption = mainMenuScanner.nextLine();
        return switchOption;
    }
    public static String getEmail() {
        String email = null;
        String emailRegex = "^(.+)@(.+).(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        boolean keepRunning = true;

        while (keepRunning) {
            try {
                Scanner emailScan = new Scanner(System.in);
                System.out.println("Enter Email");
                email = emailScan.nextLine();
                if (!pattern.matcher(email).matches()) {
                    throw new IllegalArgumentException();
                } else {
                    keepRunning = false;
                }
            } catch (Exception ex) {
                System.out.println("Invalid Email");
            }
        }
        return email;
    }

    public static String getFirstName(){
        String firstName = null;
        return firstName;
    }
    public static String getLastName(){
        String lastName = null;
        return lastName;
    }



}
