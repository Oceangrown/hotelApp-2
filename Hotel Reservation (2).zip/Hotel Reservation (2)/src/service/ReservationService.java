package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {
    private static ReservationService reservationService;
    public static ReservationService getInstance(){
        if(reservationService == null){
            reservationService = new ReservationService();
        }
        return reservationService;
    }
    private static final Map<String, IRoom> roomInfo = new HashMap<String, IRoom>();
    private static final Map<String, Collection<Reservation>> reservationInfo = new HashMap<>();


    public static void addRoom(IRoom room){
        roomInfo.put(room.getRoomNumber(), room);
    }
    public static IRoom getARoom(String roomId){
        return roomInfo.get(roomId);
    }
    public static Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        if(!roomInfo.isEmpty()){
            return null;
        }
        else{
            return (Reservation) roomInfo;
        }
    }
    public static Collection<IRoom> findRooms(){
        Collection<IRoom> availableRooms = new LinkedList<>();
        for(IRoom room : availableRooms){
            if(!reservationInfo.isEmpty()){
                availableRooms.add(room);
            }
        }
        return availableRooms;

    }
    public static Collection<Reservation> getCustomersReservation(Customer customer){
        return reservationInfo.get(customer.getEmail());
    }
    public static Collection<IRoom> printAllReservations(){
        reservationInfo.values();
        return null;
    }
    public Collection<Reservation> storeAllReservations(){
        Collection<Reservation> allReservations = new LinkedList<>();
        for(Collection<Reservation> customerReservations : reservationInfo.values()){
            allReservations.addAll(customerReservations);
        }
        return allReservations;

    }


}
